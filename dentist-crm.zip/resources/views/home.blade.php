@extends('layouts.main-layout')

@section('content')
    @if (session('error'))
        <div class="alert alert-danger" role="alert">
            {{ session('error') }}
        </div>
    @endif

    @if (session('success'))
        <div class="alert alert-success" role="alert">
            {{ session('success') }}
        </div>
    @endif
    <div class="row my-4">
        <!-- Small table -->
        <div class="col-md-12">
            <div class="card shadow">
                <div class="card-body">
                    <!-- table -->
                    <table class="table datatables" id="dataTable-1">
                        <thead>
                            <tr>
                                <th>Patient Id</th>
                                <th>Patient Name</th>
                                <th>Patient Phone</th>
                                <th>Patient Phone 2</th>
                                <th>Branch</th>
                                <th>Doctor Name</th>
                                <th>Services</th>
                                <th>Appointment</th>
                                <th>Notes</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($data as $appointment)
                                <tr>
                                    <td>{{ $appointment->patient->code }}</td>
                                    <td>{{ $appointment->patient->name }}</td>
                                    <td>{{ $appointment->patient->phone }}</td>
                                    <td>{{ $appointment->patient->phone2 }}</td>
                                    <td>{{ $appointment->branch?->name }}</td>
                                    <td>{{ $appointment->doctor->name }}</td>
                                    <td>{{ $appointment->selectedServices }}</td>
                                    <td>{{ $appointment->formatedTime }}</td>
                                    <td>{{ $appointment->notes }}</td>
                                    <td>
                                        <a class="btn mb-1 btn-sm btn-info"
                                            href="{{ route('appointments.edit', ['appointment' => $appointment->id]) }}">Edit</a>

                                        @if (auth()->user()->is_admin || auth()->user()->is_doctor)
                                            <a href="{{ route('appointments.markCompleted', ['appointment' => $appointment->id]) }}"
                                                class="btn mb-1 btn-sm btn-success">Completed</a>
                                        @endif

                                        <a href="{{ route('patients.file', ['patient' => $appointment->patient->id]) }}"
                                            class="btn mb-1 btn-sm btn-warning">Patient File</a>

                                        <form class="d-inline mb-1" method="POST"
                                            action="{{ route('appointments.destroy', ['appointment' => $appointment->id]) }}">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div> <!-- simple table -->
    </div> <!-- end section -->
@endsection

@section('script')
    <script>
        $('#dataTable-1').DataTable({
            order: []
        });
    </script>
@endsection
