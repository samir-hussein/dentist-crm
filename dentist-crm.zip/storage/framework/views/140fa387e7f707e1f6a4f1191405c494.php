<?php $__env->startSection('title', 'Schdule Pattern'); ?>

<?php $__env->startSection('page-path-prefix', 'SETTINGS > SCHEDULE > '); ?>

<?php $__env->startSection('page-path', 'DAYS'); ?>

<?php $__env->startSection('settings-active', 'active-link'); ?>

<?php $__env->startSection('buttons'); ?>
    <a href="<?php echo e(route('schdule-days.index')); ?>"><button type="button" class="btn btn-dark"><span
                class="fe fe-arrow-left fe-12 mr-2"></span>Back</button></a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card shadow mb-4">
                <div class="card-body">
                    <form action="<?php echo e(route('schdule-days.store')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="form-row">
                            <div class="form-group col-12">
                                <label for="simple-select2">Day</label>
                                <select class="form-control select2" id="simple-select2" name="day">
                                    <option <?php echo e(old('day') == 'saturday' ? 'selected' : ''); ?> value="saturday">Saturday
                                    </option>
                                    <option <?php echo e(old('day') == 'sunday' ? 'selected' : ''); ?> value="sunday">Sunday</option>
                                    <option <?php echo e(old('day') == 'monday' ? 'selected' : ''); ?> value="monday">Monday</option>
                                    <option <?php echo e(old('day') == 'tuesday' ? 'selected' : ''); ?> value="tuesday">Tuesday</option>
                                    <option <?php echo e(old('day') == 'wednesday' ? 'selected' : ''); ?> value="wednesday">Wednesday
                                    </option>
                                    <option <?php echo e(old('day') == 'thursday' ? 'selected' : ''); ?> value="thursday">Thursday
                                    </option>
                                    <option <?php echo e(old('day') == 'friday' ? 'selected' : ''); ?> value="friday">Friday</option>
                                </select>
                                <?php $__errorArgs = ['day'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p style="color: red">* <?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div> <!-- form-group -->
                        </div>
                        <div id="appointments">
                            <div class="form-row">
                                <div class="form-group col-12">
                                    <label for="time">Appointment Time</label>
                                    <input type="time" class="form-control" value="<?php echo e(old('times.0')); ?>" name="times[]">
                                    <?php $__errorArgs = ['times.0'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p style="color: red">* <?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <button type="button" class="mt-2 delete-time btn btn-danger btn-sm">Delete</button>
                                </div>
                            </div>
                        </div>
                        <div class="mb-2">
                            <button type="button" id="add-appointment" class="btn btn-warning">Add Another
                                Appointment</button>
                        </div>
                        <button type="submit" class="btn btn-primary">Save</button>
                    </form>
                </div> <!-- /. card-body -->
            </div> <!-- /. card -->
        </div> <!-- /. col -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).on("click", "#add-appointment", function() {
            var html =
                `
                <div class="form-row">
                    <div class="form-group col-12">
                        <label for="time">Appointment Time</label>
                        <input type="time" class="form-control" value="<?php echo e(old('times[]')); ?>" name="times[]">
                        <?php $__errorArgs = ['times[]'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p style="color: red">* <?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <button type="button" class="mt-2 delete-time btn btn-danger btn-sm">Delete</button>
                    </div>

                </div>
                `;
            $("#appointments").append(html);
        })

        $(document).on('click', ".delete-time", function() {
            $(this).closest('.form-row').remove();
        })
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\dentist-crm\resources\views/schdule-day/create.blade.php ENDPATH**/ ?>