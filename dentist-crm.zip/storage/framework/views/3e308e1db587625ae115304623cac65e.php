<?php $__env->startSection('title', 'Schdule Dates'); ?>

<?php $__env->startSection('page-path-prefix', 'SETTINGS > SCHEDULE > '); ?>

<?php $__env->startSection('page-path', 'DATES'); ?>

<?php $__env->startSection('settings-active', 'active-link'); ?>

<?php $__env->startSection('buttons'); ?>
    <a href="<?php echo e(route('schdule-dates.index')); ?>"><button type="button" class="btn btn-dark"><span
                class="fe fe-arrow-left fe-12 mr-2"></span>Back</button></a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger" role="alert">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('success')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <div class="row my-4">
        <!-- Small table -->
        <div class="col-md-12">
            <h4><?php echo e($data->schduleDay->day); ?> - <?php echo e($data->date->format('d-m-Y')); ?></h4>
            <div class="card shadow">
                <div class="card-body">
                    <!-- table -->
                    <table class="table datatables" id="dataTable-1">
                        <thead>
                            <tr>
                                <th>Time</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data->appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <form action="<?php echo e(route('times.update', ['time' => $appointment->id])); ?>"
                                            method="post">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('put'); ?>
                                            <input type="time" class="form-control"
                                                value="<?php echo e($appointment->manually_updated_time ? \Carbon\Carbon::parse($appointment->manually_updated_time)->format('H:i') : \Carbon\Carbon::parse($appointment->time)->format('H:i')); ?>"
                                                name="time">
                                            <button id="time<?php echo e($appointment->id); ?>" type="submit" hidden
                                                class="btn btn-primary btn-sm">Save</button>
                                        </form>
                                    </td>
                                    <td>
                                        <button data-id="time<?php echo e($appointment->id); ?>"
                                            data-url="<?php echo e(route('times.update', ['time' => $appointment->id])); ?>"
                                            class="update-time btn btn-primary btn-sm">
                                            <span class="fe fe-edit fe-12 mr-2"></span> Save Updated Time
                                        </button>
                                        <form class="d-inline"
                                            action="<?php echo e(route('times.destroy', ['time' => $appointment->id])); ?>"
                                            method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger btn-sm">
                                                <span class="fe fe-trash-2 fe-12 mr-2"></span> Delete
                                            </button>
                                        </form>
                                    </td>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div> <!-- simple table -->
    </div> <!-- end section -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).on("click", ".update-time", function() {
            var id = $(this).data("id");
            $("#" + id).click();
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\dentist-crm\resources\views/schdule-date/show.blade.php ENDPATH**/ ?>