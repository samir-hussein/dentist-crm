<?php if(count($treatments) > 0): ?>
    <ul class="nav nav-pills nav-fill mb-3" id="pills-tab" role="tablist">
        <?php $__currentLoopData = $treatments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $treatment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="nav-item tab-btn" data-needlab="<?php echo e($treatment->treatmentType->need_labs); ?>"
                data-first="<?php echo e($loop->first ? 1 : 0); ?>">
                <a class="nav-link <?php echo e($loop->first ? 'active' : ''); ?>"
                    id="<?php echo e(str_replace([' ', '.'], '_', $treatment->treatmentType->name)); ?>-tab" data-toggle="pill"
                    href="#<?php echo e(str_replace([' ', '.'], '_', $treatment->treatmentType->name)); ?>" role="tab"
                    aria-controls="<?php echo e(str_replace([' ', '.'], '_', $treatment->treatmentType->name)); ?>"
                    aria-selected="true"><?php echo e($treatment->treatmentType->name); ?></a>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <li class="nav-item tab-btn" data-needlab="0">
            <a class="nav-link" id="notes-tab" data-toggle="pill" href="#notes" role="tab" aria-controls="notes"
                aria-selected="false">Write Notes</a>
        </li>
    </ul>
    <div class="tab-content mb-1" id="pills-tabContent">
        <?php $__currentLoopData = $treatments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $treatment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="tab-pane fade <?php echo e($loop->first ? 'show active' : ''); ?>"
                id="<?php echo e(str_replace([' ', '.'], '_', $treatment->treatmentType->name)); ?>" role="tabpanel"
                aria-labelledby="<?php echo e(str_replace([' ', '.'], '_', $treatment->treatmentType->name)); ?>-tab">
                <div class="row">
                    <?php $__currentLoopData = $treatment->treatmentType->sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card-body col-6">
                            <h6><?php echo e($section->title); ?></h6>
                            <?php if($section->multi_selection): ?>
                                <?php $__currentLoopData = $section->attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox" data-attr="<?php echo e($attribute->id); ?>"
                                            data-id="<?php echo e(str_replace([' ', '.'], '_', $section->title)); ?>-<?php echo e($attribute->id); ?>"
                                            class="checkbox-inp custom-control-input"
                                            id="<?php echo e($section->id); ?>-<?php echo e($attribute->id); ?>">
                                        <label class="custom-control-label"
                                            for="<?php echo e($section->id); ?>-<?php echo e($attribute->id); ?>"><?php echo e($attribute->name); ?></label>
                                    </div>
                                    <?php if($attribute->has_inputs && count($attribute->inputs) > 0): ?>
                                        <div class="mt-2 d-none"
                                            id="<?php echo e(str_replace([' ', '.'], '_', $section->title)); ?>-<?php echo e($attribute->id); ?>">
                                            <?php $__currentLoopData = $attribute->inputs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $input): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="form-group row">
                                                    <label for="<?php echo e($input->id); ?>"
                                                        class="col-sm-3 col-form-label"><?php echo e($input->name); ?></label>
                                                    <div class="col-sm-9">
                                                        <input type="text"
                                                            class="form-control attr-inputs <?php echo e($treatment->treatmentType->need_labs ? 'lab-inputs' : ''); ?>"
                                                            id="<?php echo e($input->id); ?>" data-name="<?php echo e($input->name); ?>"
                                                            data-attr="<?php echo e($attribute->id); ?>"
                                                            data-id="<?php echo e($input->id); ?>" value="<?php echo e($input->value); ?>">
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <?php $__currentLoopData = $section->attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="custom-control custom-radio">
                                        <input type="radio" data-attr="<?php echo e($attribute->id); ?>"
                                            data-id="<?php echo e(str_replace([' ', '.'], '_', $section->title)); ?>-<?php echo e($attribute->id); ?>"
                                            id="<?php echo e($section->id); ?>-<?php echo e($attribute->id); ?>" name="customRadio"
                                            class="custom-control-input">
                                        <label class="custom-control-label"
                                            for="<?php echo e($section->id); ?>-<?php echo e($attribute->id); ?>"><?php echo e($attribute->name); ?></label>
                                    </div>
                                    <?php if($attribute->has_inputs && count($attribute->inputs) > 0): ?>
                                        <div class="mt-2 d-none <?php echo e(str_replace([' ', '.'], '_', $section->title)); ?>"
                                            id="<?php echo e(str_replace([' ', '.'], '_', $section->title)); ?>-<?php echo e($attribute->id); ?>">
                                            <?php $__currentLoopData = $attribute->inputs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $input): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="form-group row">
                                                    <label for="<?php echo e($input->id); ?>"
                                                        class="col-sm-3 col-form-label"><?php echo e($input->name); ?></label>
                                                    <div class="col-sm-9">
                                                        <input type="text"
                                                            class="form-control attr-inputs <?php echo e($treatment->treatmentType->need_labs ? 'lab-inputs' : ''); ?>"
                                                            id="<?php echo e($input->id); ?>" data-id="<?php echo e($input->id); ?>"
                                                            data-name="<?php echo e($input->name); ?>"
                                                            data-attr="<?php echo e($attribute->id); ?>"
                                                            value="<?php echo e($input->value); ?>">
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="tab-pane fade" id="notes" role="tabpanel" aria-labelledby="notes-tab">
            <h6>Write Notes</h6>
            <textarea name="" dir="auto" class="form-control" id="notes-inp" cols="30" rows="10"></textarea>
        </div>
    </div>

    <div id="lab-div" class="d-none p-2">
        <div class="form-group">
            <div class="custom-control custom-checkbox">
                <input type="checkbox" class="custom-control-input lab-done" id="cementation-delivery">
                <label class="custom-control-label" for="cementation-delivery">Done</label>
            </div> <!-- form-group -->
        </div>
        <h6>Lab Service</h6>
        <div class="form-row">
            <div class="form-group col-12 col-md-6">
                <label for="select" class="d-block">Services</label>
                <select multiple class="form-control select2-multi lab-work d-block w-100" id="select"
                    autocomplete="off">
                    <?php $__currentLoopData = $labsServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($service->name); ?>"><?php echo e($service->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group col-12 col-md-6">
                <label for="simple-select">Labs</label>
                <select class="form-control select2 lab" id="simple-select">
                    <option value="">select lab</option>
                    <?php $__currentLoopData = $labs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($lab->id); ?>"><?php echo e($lab->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div> <!-- form-group -->
        </div>
        <div class="form-row">
            <div class="form-group col-12 col-md-6">
                <label>Charges</label>
                <input type="password" class="form-control" min="0" id="cost"
                    autocomplete="new-password">
            </div> <!-- form-group -->
            <div class="form-group col-12 col-md-6">
                <label>Date</label>
                <input type="date" class="form-control" id="sent">
            </div> <!-- form-group -->
        </div>
    </div>

<?php endif; ?>
<?php /**PATH D:\dentist-crm\resources\views/ajax-components/treatment-tabs.blade.php ENDPATH**/ ?>