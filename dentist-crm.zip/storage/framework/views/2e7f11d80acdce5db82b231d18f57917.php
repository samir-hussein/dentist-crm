<h5 class="card-title">Tooth</h5>
<div id="tooth-uploaded" class="splide" role="group" aria-label="Splide Basic HTML Example">
    <div class="splide__track">
        <ul class="splide__list">
            <?php if(count($panorama) > 0): ?>
                <?php $__currentLoopData = $panorama; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="splide__slide" data-toggle="modal" data-target="#panorama<?php echo e($img['id']); ?>"><img
                            src="<?php echo e($img['url']); ?>" alt=""></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </ul>
    </div>
</div>
<?php /**PATH D:\dentist-crm\resources\views/ajax-components/tooth-panorama-slider.blade.php ENDPATH**/ ?>