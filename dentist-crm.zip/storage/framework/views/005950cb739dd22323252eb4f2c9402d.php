<?php $__env->startSection('title', 'Patients'); ?>

<?php $__env->startSection('buttons'); ?>
    <a href="<?php echo e(route('patients.index')); ?>"><button type="button" class="btn btn-dark"><span
                class="fe fe-arrow-left fe-12 mr-2"></span>Back</button></a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card shadow mb-4">
                <div class="card-body">
                    <form action="<?php echo e(route('patients.store')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="form-row">
                            <div class="form-group col-6">
                                <label for="name">Full Name</label>
                                <input type="text" class="form-control" id="name" value="<?php echo e(old('name')); ?>"
                                    name="name" dir="auto">
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p style="color: red">* <?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group col-6">
                                <label for="multi-select2" class="d-block">Medical History</label>
                                <select multiple name="medical_history[]" class="form-control select2-multi d-block w-100"
                                    id="multi-select2">
                                    <?php $__currentLoopData = $data->medicalHistory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medicalHistory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($medicalHistory->name); ?>"><?php echo e($medicalHistory->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="phone">Phone</label>
                                <input type="text" class="form-control" id="phone" value="<?php echo e(old('phone')); ?>"
                                    name="phone">
                                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p style="color: red">* <?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="phone2">Phone 2</label>
                                <input type="text" class="form-control" id="phone2" value="<?php echo e(old('phone2')); ?>"
                                    name="phone2">
                                <?php $__errorArgs = ['phone2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p style="color: red">* <?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="date_of_birth">Date Of Birth</label>
                                <input type="date" class="form-control" id="date_of_birth"
                                    value="<?php echo e(old('date_of_birth')); ?>" name="date_of_birth">
                                <?php $__errorArgs = ['date_of_birth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p style="color: red">* <?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="gender">Gender</label>
                                <select id="gender" name="gender" class="form-control">
                                    <option <?php echo e(old('gender') == 'Male' ? 'selected' : ''); ?> value="Male">Male</option>
                                    <option <?php echo e(old('gender') == 'Female' ? 'selected' : ''); ?> value="Female">Female
                                    </option>
                                </select>
                                <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p style="color: red">* <?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="form-group col-6">
                                <label for="simple-select3">Nationality</label>
                                <select class="form-control select2" id="simple-select3" name="nationality">
                                    <option <?php echo e(old('nationality') == 'afghan' ? 'selected' : ''); ?> value="afghan">Afghan
                                    </option>
                                    <option <?php echo e(old('nationality') == 'albanian' ? 'selected' : ''); ?> value="albanian">
                                        Albanian</option>
                                    <option <?php echo e(old('nationality') == 'algerian' ? 'selected' : ''); ?> value="algerian">
                                        Algerian</option>
                                    <option <?php echo e(old('nationality') == 'american' ? 'selected' : ''); ?> value="american">
                                        American</option>
                                    <option <?php echo e(old('nationality') == 'andorran' ? 'selected' : ''); ?> value="andorran">
                                        Andorran</option>
                                    <option <?php echo e(old('nationality') == 'angolan' ? 'selected' : ''); ?> value="angolan">Angolan
                                    </option>
                                    <option <?php echo e(old('nationality') == 'antiguan' ? 'selected' : ''); ?> value="antiguan">
                                        Antiguan</option>
                                    <option <?php echo e(old('nationality') == 'argentine' ? 'selected' : ''); ?> value="argentine">
                                        Argentine</option>
                                    <option <?php echo e(old('nationality') == 'armenian' ? 'selected' : ''); ?> value="armenian">
                                        Armenian</option>
                                    <option <?php echo e(old('nationality') == 'australian' ? 'selected' : ''); ?> value="australian">
                                        Australian</option>
                                    <option <?php echo e(old('nationality') == 'austrian' ? 'selected' : ''); ?> value="austrian">
                                        Austrian</option>
                                    <option <?php echo e(old('nationality') == 'azerbaijani' ? 'selected' : ''); ?>

                                        value="azerbaijani">Azerbaijani</option>
                                    <option <?php echo e(old('nationality') == 'bahamian' ? 'selected' : ''); ?> value="bahamian">
                                        Bahamian</option>
                                    <option <?php echo e(old('nationality') == 'bahraini' ? 'selected' : ''); ?> value="bahraini">
                                        Bahraini</option>
                                    <option <?php echo e(old('nationality') == 'bangladeshi' ? 'selected' : ''); ?>

                                        value="bangladeshi">Bangladeshi</option>
                                    <option <?php echo e(old('nationality') == 'barbadian' ? 'selected' : ''); ?> value="barbadian">
                                        Barbadian</option>
                                    <option <?php echo e(old('nationality') == 'belarusian' ? 'selected' : ''); ?> value="belarusian">
                                        Belarusian</option>
                                    <option <?php echo e(old('nationality') == 'belgian' ? 'selected' : ''); ?> value="belgian">Belgian
                                    </option>
                                    <option <?php echo e(old('nationality') == 'belizean' ? 'selected' : ''); ?> value="belizean">
                                        Belizean</option>
                                    <option <?php echo e(old('nationality') == 'beninese' ? 'selected' : ''); ?> value="beninese">
                                        Beninese</option>
                                    <option <?php echo e(old('nationality') == 'bhutanese' ? 'selected' : ''); ?> value="bhutanese">
                                        Bhutanese</option>
                                    <option <?php echo e(old('nationality') == 'bolivian' ? 'selected' : ''); ?> value="bolivian">
                                        Bolivian</option>
                                    <option <?php echo e(old('nationality') == 'bosnian' ? 'selected' : ''); ?> value="bosnian">Bosnian
                                    </option>
                                    <option <?php echo e(old('nationality') == 'botswanan' ? 'selected' : ''); ?> value="botswanan">
                                        Botswanan</option>
                                    <option <?php echo e(old('nationality') == 'brazilian' ? 'selected' : ''); ?> value="brazilian">
                                        Brazilian</option>
                                    <option <?php echo e(old('nationality') == 'british' ? 'selected' : ''); ?> value="british">British
                                    </option>
                                    <option <?php echo e(old('nationality') == 'bruneian' ? 'selected' : ''); ?> value="bruneian">
                                        Bruneian</option>
                                    <option <?php echo e(old('nationality') == 'bulgarian' ? 'selected' : ''); ?> value="bulgarian">
                                        Bulgarian</option>
                                    <option <?php echo e(old('nationality') == 'burkinabe' ? 'selected' : ''); ?> value="burkinabe">
                                        Burkinabe</option>
                                    <option <?php echo e(old('nationality') == 'burmese' ? 'selected' : ''); ?> value="burmese">Burmese
                                    </option>
                                    <option <?php echo e(old('nationality') == 'burundian' ? 'selected' : ''); ?> value="burundian">
                                        Burundian</option>
                                    <option <?php echo e(old('nationality') == 'cambodian' ? 'selected' : ''); ?> value="cambodian">
                                        Cambodian</option>
                                    <option <?php echo e(old('nationality') == 'cameroonian' ? 'selected' : ''); ?>

                                        value="cameroonian">Cameroonian</option>
                                    <option <?php echo e(old('nationality') == 'canadian' ? 'selected' : ''); ?> value="canadian">
                                        Canadian</option>
                                    <option <?php echo e(old('nationality') == 'cape_verdean' ? 'selected' : ''); ?>

                                        value="cape_verdean">Cape Verdean</option>
                                    <option <?php echo e(old('nationality') == 'central_african' ? 'selected' : ''); ?>

                                        value="central_african">Central African</option>
                                    <option <?php echo e(old('nationality') == 'chadian' ? 'selected' : ''); ?> value="chadian">
                                        Chadian
                                    </option>
                                    <option <?php echo e(old('nationality') == 'chilean' ? 'selected' : ''); ?> value="chilean">
                                        Chilean
                                    </option>
                                    <option <?php echo e(old('nationality') == 'chinese' ? 'selected' : ''); ?> value="chinese">
                                        Chinese
                                    </option>
                                    <option <?php echo e(old('nationality') == 'colombian' ? 'selected' : ''); ?> value="colombian">
                                        Colombian</option>
                                    <option <?php echo e(old('nationality') == 'comoran' ? 'selected' : ''); ?> value="comoran">
                                        Comoran</option>
                                    <option <?php echo e(old('nationality') == 'congolese' ? 'selected' : ''); ?> value="congolese">
                                        Congolese</option>
                                    <option <?php echo e(old('nationality') == 'costa_rican' ? 'selected' : ''); ?>

                                        value="costa_rican">Costa Rican</option>
                                    <option <?php echo e(old('nationality') == 'croatian' ? 'selected' : ''); ?> value="croatian">
                                        Croatian</option>
                                    <option <?php echo e(old('nationality') == 'cuban' ? 'selected' : ''); ?> value="cuban">Cuban
                                    </option>
                                    <option <?php echo e(old('nationality') == 'cypriot' ? 'selected' : ''); ?> value="cypriot">
                                        Cypriot</option>
                                    <option <?php echo e(old('nationality') == 'czech' ? 'selected' : ''); ?> value="czech">Czech
                                    </option>
                                    <option <?php echo e(old('nationality') == 'danish' ? 'selected' : ''); ?> value="danish">Danish
                                    </option>
                                    <option <?php echo e(old('nationality') == 'djiboutian' ? 'selected' : ''); ?> value="djiboutian">
                                        Djiboutian</option>
                                    <option <?php echo e(old('nationality') == 'dominican' ? 'selected' : ''); ?> value="dominican">
                                        Dominican</option>
                                    <option <?php echo e(old('nationality') == 'dutch' ? 'selected' : ''); ?> value="dutch">Dutch
                                    </option>
                                    <option <?php echo e(old('nationality') == 'east_timorese' ? 'selected' : ''); ?>

                                        value="east_timorese">East Timorese</option>
                                    <option <?php echo e(old('nationality') == 'ecuadorean' ? 'selected' : ''); ?> value="ecuadorean">
                                        Ecuadorean</option>
                                    <option <?php echo e(old('nationality') == 'egyptian' ? 'selected' : ''); ?> value="egyptian">
                                        Egyptian</option>
                                    <option <?php echo e(old('nationality') == 'emirati' ? 'selected' : ''); ?> value="emirati">
                                        Emirati</option>
                                    <option <?php echo e(old('nationality') == 'equatoguinean' ? 'selected' : ''); ?>

                                        value="equatoguinean">Equatoguinean</option>
                                    <option <?php echo e(old('nationality') == 'eritrean' ? 'selected' : ''); ?> value="eritrean">
                                        Eritrean</option>
                                    <option <?php echo e(old('nationality') == 'estonian' ? 'selected' : ''); ?> value="estonian">
                                        Estonian</option>
                                    <option <?php echo e(old('nationality') == 'ethiopian' ? 'selected' : ''); ?> value="ethiopian">
                                        Ethiopian</option>
                                    <option <?php echo e(old('nationality') == 'fijian' ? 'selected' : ''); ?> value="fijian">Fijian
                                    </option>
                                    <option <?php echo e(old('nationality') == 'filipino' ? 'selected' : ''); ?> value="filipino">
                                        Filipino</option>
                                    <option <?php echo e(old('nationality') == 'finnish' ? 'selected' : ''); ?> value="finnish">
                                        Finnish</option>
                                    <option <?php echo e(old('nationality') == 'french' ? 'selected' : ''); ?> value="french">French
                                    </option>
                                    <option <?php echo e(old('nationality') == 'gabonese' ? 'selected' : ''); ?> value="gabonese">
                                        Gabonese</option>
                                    <option <?php echo e(old('nationality') == 'gambian' ? 'selected' : ''); ?> value="gambian">
                                        Gambian</option>
                                    <option <?php echo e(old('nationality') == 'georgian' ? 'selected' : ''); ?> value="georgian">
                                        Georgian</option>
                                    <option <?php echo e(old('nationality') == 'german' ? 'selected' : ''); ?> value="german">German
                                    </option>
                                    <option <?php echo e(old('nationality') == 'ghanaian' ? 'selected' : ''); ?> value="ghanaian">
                                        Ghanaian</option>
                                    <option <?php echo e(old('nationality') == 'greek' ? 'selected' : ''); ?> value="greek">Greek
                                    </option>
                                    <option <?php echo e(old('nationality') == 'grenadian' ? 'selected' : ''); ?> value="grenadian">
                                        Grenadian</option>
                                    <option <?php echo e(old('nationality') == 'guatemalan' ? 'selected' : ''); ?> value="guatemalan">
                                        Guatemalan</option>
                                    <option <?php echo e(old('nationality') == 'guinean' ? 'selected' : ''); ?> value="guinean">
                                        Guinean</option>
                                    <option <?php echo e(old('nationality') == 'guinea_bissauan' ? 'selected' : ''); ?>

                                        value="guinea_bissauan">Guinea-Bissauan</option>
                                    <option <?php echo e(old('nationality') == 'guyanese' ? 'selected' : ''); ?> value="guyanese">
                                        Guyanese</option>
                                    <option <?php echo e(old('nationality') == 'haitian' ? 'selected' : ''); ?> value="haitian">
                                        Haitian</option>
                                    <option <?php echo e(old('nationality') == 'honduran' ? 'selected' : ''); ?> value="honduran">
                                        Honduran</option>
                                    <option <?php echo e(old('nationality') == 'hungarian' ? 'selected' : ''); ?> value="hungarian">
                                        Hungarian</option>
                                    <option <?php echo e(old('nationality') == 'icelander' ? 'selected' : ''); ?> value="icelander">
                                        Icelander</option>
                                    <option <?php echo e(old('nationality') == 'indian' ? 'selected' : ''); ?> value="indian">Indian
                                    </option>
                                    <option <?php echo e(old('nationality') == 'indonesian' ? 'selected' : ''); ?> value="indonesian">
                                        Indonesian</option>
                                    <option <?php echo e(old('nationality') == 'iranian' ? 'selected' : ''); ?> value="iranian">
                                        Iranian</option>
                                    <option <?php echo e(old('nationality') == 'iraqi' ? 'selected' : ''); ?> value="iraqi">Iraqi
                                    </option>
                                    <option <?php echo e(old('nationality') == 'irish' ? 'selected' : ''); ?> value="irish">Irish
                                    </option>
                                    <option <?php echo e(old('nationality') == 'israeli' ? 'selected' : ''); ?> value="israeli">
                                        Israeli</option>
                                    <option <?php echo e(old('nationality') == 'italian' ? 'selected' : ''); ?> value="italian">
                                        Italian</option>
                                    <option <?php echo e(old('nationality') == 'ivorian' ? 'selected' : ''); ?> value="ivorian">
                                        Ivorian</option>
                                    <option <?php echo e(old('nationality') == 'jamaican' ? 'selected' : ''); ?> value="jamaican">
                                        Jamaican</option>
                                    <option <?php echo e(old('nationality') == 'japanese' ? 'selected' : ''); ?> value="japanese">
                                        Japanese</option>
                                    <option <?php echo e(old('nationality') == 'jordanian' ? 'selected' : ''); ?> value="jordanian">
                                        Jordanian</option>
                                    <option <?php echo e(old('nationality') == 'kazakh' ? 'selected' : ''); ?> value="kazakh">Kazakh
                                    </option>
                                    <option <?php echo e(old('nationality') == 'kenyan' ? 'selected' : ''); ?> value="kenyan">Kenyan
                                    </option>
                                    <option <?php echo e(old('nationality') == 'kiribati' ? 'selected' : ''); ?> value="kiribati">
                                        Kiribati</option>
                                    <option <?php echo e(old('nationality') == 'kittitian' ? 'selected' : ''); ?> value="kittitian">
                                        Kittitian</option>
                                    <option <?php echo e(old('nationality') == 'kosovar' ? 'selected' : ''); ?> value="kosovar">
                                        Kosovar</option>
                                    <option <?php echo e(old('nationality') == 'kuwaiti' ? 'selected' : ''); ?> value="kuwaiti">
                                        Kuwaiti</option>
                                    <option <?php echo e(old('nationality') == 'kyrgyz' ? 'selected' : ''); ?> value="kyrgyz">Kyrgyz
                                    </option>
                                    <option <?php echo e(old('nationality') == 'lao' ? 'selected' : ''); ?> value="lao">Lao
                                    </option>
                                    <option <?php echo e(old('nationality') == 'latvian' ? 'selected' : ''); ?> value="latvian">
                                        Latvian</option>
                                    <option <?php echo e(old('nationality') == 'lebanese' ? 'selected' : ''); ?> value="lebanese">
                                        Lebanese</option>
                                    <option <?php echo e(old('nationality') == 'liberian' ? 'selected' : ''); ?> value="liberian">
                                        Liberian</option>
                                    <option <?php echo e(old('nationality') == 'libyan' ? 'selected' : ''); ?> value="libyan">Libyan
                                    </option>
                                    <option <?php echo e(old('nationality') == 'liechtenstein' ? 'selected' : ''); ?>

                                        value="liechtenstein">Liechtenstein</option>
                                    <option <?php echo e(old('nationality') == 'lithuanian' ? 'selected' : ''); ?>

                                        value="lithuanian">Lithuanian</option>
                                    <option <?php echo e(old('nationality') == 'luxembourger' ? 'selected' : ''); ?>

                                        value="luxembourger">Luxembourger</option>
                                    <option <?php echo e(old('nationality') == 'macedonian' ? 'selected' : ''); ?>

                                        value="macedonian">Macedonian</option>
                                    <option <?php echo e(old('nationality') == 'malagasy' ? 'selected' : ''); ?> value="malagasy">
                                        Malagasy</option>
                                    <option <?php echo e(old('nationality') == 'malawian' ? 'selected' : ''); ?> value="malawian">
                                        Malawian</option>
                                    <option <?php echo e(old('nationality') == 'malaysian' ? 'selected' : ''); ?> value="malaysian">
                                        Malaysian</option>
                                    <option <?php echo e(old('nationality') == 'maldivian' ? 'selected' : ''); ?> value="maldivian">
                                        Maldivian</option>
                                    <option <?php echo e(old('nationality') == 'malian' ? 'selected' : ''); ?> value="malian">Malian
                                    </option>
                                    <option <?php echo e(old('nationality') == 'maltese' ? 'selected' : ''); ?> value="maltese">
                                        Maltese</option>
                                    <option <?php echo e(old('nationality') == 'marshallese' ? 'selected' : ''); ?>

                                        value="marshallese">Marshallese</option>
                                    <option <?php echo e(old('nationality') == 'mauritanian' ? 'selected' : ''); ?>

                                        value="mauritanian">Mauritanian</option>
                                    <option <?php echo e(old('nationality') == 'mauritian' ? 'selected' : ''); ?> value="mauritian">
                                        Mauritian</option>
                                    <option <?php echo e(old('nationality') == 'mexican' ? 'selected' : ''); ?> value="mexican">
                                        Mexican</option>
                                    <option <?php echo e(old('nationality') == 'micronesian' ? 'selected' : ''); ?>

                                        value="micronesian">Micronesian</option>
                                    <option <?php echo e(old('nationality') == 'moldovan' ? 'selected' : ''); ?> value="moldovan">
                                        Moldovan</option>
                                    <option <?php echo e(old('nationality') == 'monacan' ? 'selected' : ''); ?> value="monacan">
                                        Monacan</option>
                                    <option <?php echo e(old('nationality') == 'mongolian' ? 'selected' : ''); ?> value="mongolian">
                                        Mongolian</option>
                                    <option <?php echo e(old('nationality') == 'montenegrin' ? 'selected' : ''); ?>

                                        value="montenegrin">Montenegrin</option>
                                    <option <?php echo e(old('nationality') == 'moroccan' ? 'selected' : ''); ?> value="moroccan">
                                        Moroccan</option>
                                    <option <?php echo e(old('nationality') == 'mozambican' ? 'selected' : ''); ?>

                                        value="mozambican">Mozambican</option>
                                    <option <?php echo e(old('nationality') == 'namibian' ? 'selected' : ''); ?> value="namibian">
                                        Namibian</option>
                                    <option <?php echo e(old('nationality') == 'nauruan' ? 'selected' : ''); ?> value="nauruan">
                                        Nauruan</option>
                                    <option <?php echo e(old('nationality') == 'nepalese' ? 'selected' : ''); ?> value="nepalese">
                                        Nepalese</option>
                                    <option <?php echo e(old('nationality') == 'new_zealander' ? 'selected' : ''); ?>

                                        value="new_zealander">New Zealander</option>
                                    <option <?php echo e(old('nationality') == 'nicaraguan' ? 'selected' : ''); ?>

                                        value="nicaraguan">Nicaraguan</option>
                                    <option <?php echo e(old('nationality') == 'nigerien' ? 'selected' : ''); ?> value="nigerien">
                                        Nigerien</option>
                                    <option <?php echo e(old('nationality') == 'nigerian' ? 'selected' : ''); ?> value="nigerian">
                                        Nigerian</option>
                                    <option <?php echo e(old('nationality') == 'niuean' ? 'selected' : ''); ?> value="niuean">Niuean
                                    </option>
                                    <option <?php echo e(old('nationality') == 'north_korean' ? 'selected' : ''); ?>

                                        value="north_korean">North Korean</option>
                                    <option <?php echo e(old('nationality') == 'northern_irish' ? 'selected' : ''); ?>

                                        value="northern_irish">Northern Irish</option>
                                    <option <?php echo e(old('nationality') == 'norwegian' ? 'selected' : ''); ?> value="norwegian">
                                        Norwegian</option>
                                    <option <?php echo e(old('nationality') == 'omani' ? 'selected' : ''); ?> value="omani">Omani
                                    </option>
                                    <option <?php echo e(old('nationality') == 'pakistani' ? 'selected' : ''); ?> value="pakistani">
                                        Pakistani</option>
                                    <option <?php echo e(old('nationality') == 'palauan' ? 'selected' : ''); ?> value="palauan">
                                        Palauan</option>
                                    <option <?php echo e(old('nationality') == 'panamanian' ? 'selected' : ''); ?>

                                        value="panamanian">Panamanian</option>
                                    <option <?php echo e(old('nationality') == 'papua_new_guinean' ? 'selected' : ''); ?>

                                        value="papua_new_guinean">Papua New Guinean</option>
                                    <option <?php echo e(old('nationality') == 'paraguayan' ? 'selected' : ''); ?>

                                        value="paraguayan">Paraguayan</option>
                                    <option <?php echo e(old('nationality') == 'peruvian' ? 'selected' : ''); ?> value="peruvian">
                                        Peruvian</option>
                                    <option <?php echo e(old('nationality') == 'polish' ? 'selected' : ''); ?> value="polish">Polish
                                    </option>
                                    <option <?php echo e(old('nationality') == 'portuguese' ? 'selected' : ''); ?>

                                        value="portuguese">Portuguese</option>
                                    <option <?php echo e(old('nationality') == 'qatari' ? 'selected' : ''); ?> value="qatari">Qatari
                                    </option>
                                    <option <?php echo e(old('nationality') == 'romanian' ? 'selected' : ''); ?> value="romanian">
                                        Romanian</option>
                                    <option <?php echo e(old('nationality') == 'russian' ? 'selected' : ''); ?> value="russian">
                                        Russian</option>
                                    <option <?php echo e(old('nationality') == 'rwandan' ? 'selected' : ''); ?> value="rwandan">
                                        Rwandan</option>
                                    <option <?php echo e(old('nationality') == 'salvadorean' ? 'selected' : ''); ?>

                                        value="salvadorean">Salvadorean</option>
                                    <option <?php echo e(old('nationality') == 'samoan' ? 'selected' : ''); ?> value="samoan">Samoan
                                    </option>
                                    <option <?php echo e(old('nationality') == 'sao_tomean' ? 'selected' : ''); ?>

                                        value="sao_tomean">Sao Tomean</option>
                                    <option <?php echo e(old('nationality') == 'saudi' ? 'selected' : ''); ?> value="saudi">Saudi
                                    </option>
                                    <option <?php echo e(old('nationality') == 'scottish' ? 'selected' : ''); ?> value="scottish">
                                        Scottish</option>
                                    <option <?php echo e(old('nationality') == 'senegalese' ? 'selected' : ''); ?>

                                        value="senegalese">Senegalese</option>
                                    <option <?php echo e(old('nationality') == 'serbian' ? 'selected' : ''); ?> value="serbian">
                                        Serbian</option>
                                    <option <?php echo e(old('nationality') == 'seychellois' ? 'selected' : ''); ?>

                                        value="seychellois">Seychellois</option>
                                    <option <?php echo e(old('nationality') == 'sierra_leonean' ? 'selected' : ''); ?>

                                        value="sierra_leonean">Sierra Leonean</option>
                                    <option <?php echo e(old('nationality') == 'singaporean' ? 'selected' : ''); ?>

                                        value="singaporean">Singaporean</option>
                                    <option <?php echo e(old('nationality') == 'slovak' ? 'selected' : ''); ?> value="slovak">Slovak
                                    </option>
                                    <option <?php echo e(old('nationality') == 'slovenian' ? 'selected' : ''); ?> value="slovenian">
                                        Slovenian</option>
                                    <option <?php echo e(old('nationality') == 'solomon_islander' ? 'selected' : ''); ?>

                                        value="solomon_islander">Solomon Islander</option>
                                    <option <?php echo e(old('nationality') == 'somali' ? 'selected' : ''); ?> value="somali">Somali
                                    </option>
                                    <option <?php echo e(old('nationality') == 'south_african' ? 'selected' : ''); ?>

                                        value="south_african">South African</option>
                                    <option <?php echo e(old('nationality') == 'south_korean' ? 'selected' : ''); ?>

                                        value="south_korean">South Korean</option>
                                    <option <?php echo e(old('nationality') == 'south_sudanese' ? 'selected' : ''); ?>

                                        value="south_sudanese">South Sudanese</option>
                                    <option <?php echo e(old('nationality') == 'spanish' ? 'selected' : ''); ?> value="spanish">
                                        Spanish</option>
                                    <option <?php echo e(old('nationality') == 'sri_lankan' ? 'selected' : ''); ?>

                                        value="sri_lankan">Sri Lankan</option>
                                    <option <?php echo e(old('nationality') == 'sudanese' ? 'selected' : ''); ?> value="sudanese">
                                        Sudanese</option>
                                    <option <?php echo e(old('nationality') == 'surinamer' ? 'selected' : ''); ?> value="surinamer">
                                        Surinamer</option>
                                    <option <?php echo e(old('nationality') == 'swazi' ? 'selected' : ''); ?> value="swazi">Swazi
                                    </option>
                                    <option <?php echo e(old('nationality') == 'swedish' ? 'selected' : ''); ?> value="swedish">
                                        Swedish</option>
                                    <option <?php echo e(old('nationality') == 'swiss' ? 'selected' : ''); ?> value="swiss">Swiss
                                    </option>
                                    <option <?php echo e(old('nationality') == 'syrian' ? 'selected' : ''); ?> value="syrian">Syrian
                                    </option>
                                    <option <?php echo e(old('nationality') == 'taiwanese' ? 'selected' : ''); ?> value="taiwanese">
                                        Taiwanese</option>
                                    <option <?php echo e(old('nationality') == 'tajik' ? 'selected' : ''); ?> value="tajik">Tajik
                                    </option>
                                    <option <?php echo e(old('nationality') == 'tanzanian' ? 'selected' : ''); ?> value="tanzanian">
                                        Tanzanian</option>
                                    <option <?php echo e(old('nationality') == 'thai' ? 'selected' : ''); ?> value="thai">Thai
                                    </option>
                                    <option <?php echo e(old('nationality') == 'togolese' ? 'selected' : ''); ?> value="togolese">
                                        Togolese</option>
                                    <option <?php echo e(old('nationality') == 'tongan' ? 'selected' : ''); ?> value="tongan">Tongan
                                    </option>
                                    <option <?php echo e(old('nationality') == 'trinidadian' ? 'selected' : ''); ?>

                                        value="trinidadian">Trinidadian</option>
                                    <option <?php echo e(old('nationality') == 'tunisian' ? 'selected' : ''); ?> value="tunisian">
                                        Tunisian</option>
                                    <option <?php echo e(old('nationality') == 'turkish' ? 'selected' : ''); ?> value="turkish">
                                        Turkish</option>
                                    <option <?php echo e(old('nationality') == 'tuvaluan' ? 'selected' : ''); ?> value="tuvaluan">
                                        Tuvaluan</option>
                                    <option <?php echo e(old('nationality') == 'ugandan' ? 'selected' : ''); ?> value="ugandan">
                                        Ugandan</option>
                                    <option <?php echo e(old('nationality') == 'ukrainian' ? 'selected' : ''); ?> value="ukrainian">
                                        Ukrainian</option>
                                    <option <?php echo e(old('nationality') == 'uruguayan' ? 'selected' : ''); ?> value="uruguayan">
                                        Uruguayan</option>
                                    <option <?php echo e(old('nationality') == 'uzbek' ? 'selected' : ''); ?> value="uzbek">Uzbek
                                    </option>
                                    <option <?php echo e(old('nationality') == 'vanuatuan' ? 'selected' : ''); ?> value="vanuatuan">
                                        Vanuatuan</option>
                                    <option <?php echo e(old('nationality') == 'venezuelan' ? 'selected' : ''); ?>

                                        value="venezuelan">Venezuelan</option>
                                    <option <?php echo e(old('nationality') == 'vietnamese' ? 'selected' : ''); ?>

                                        value="vietnamese">Vietnamese</option>
                                    <option <?php echo e(old('nationality') == 'welsh' ? 'selected' : ''); ?> value="welsh">Welsh
                                    </option>
                                    <option <?php echo e(old('nationality') == 'yemeni' ? 'selected' : ''); ?> value="yemeni">Yemeni
                                    </option>
                                    <option <?php echo e(old('nationality') == 'zambian' ? 'selected' : ''); ?> value="zambian">
                                        Zambian</option>
                                    <option <?php echo e(old('nationality') == 'zimbabwean' ? 'selected' : ''); ?>

                                        value="zimbabwean">Zimbabwean</option>
                                </select>
                                <?php $__errorArgs = ['nationality'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p style="color: red">* <?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div> <!-- form-group -->

                            <div class="form-group col-md-6">
                                <label for="need_invoice">Need Invoice</label>
                                <select id="need_invoice" name="need_invoice" class="form-control">
                                    <option <?php echo e(old('need_invoice') ? 'selected' : ''); ?> value="1">Yes</option>
                                    <option <?php echo e(!old('need_invoice') ? 'selected' : ''); ?> value="0">No</option>
                                </select>
                                <?php $__errorArgs = ['need_invoice'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p style="color: red">* <?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary">Save</button>
                    </form>
                </div> <!-- /. card-body -->
            </div> <!-- /. card -->
        </div> <!-- /. col -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function() {
            $('#multi-select2').select2({
                tags: true, // Enable custom tagging
                tokenSeparators: [',', ' '], // Allow comma or space for creating new tags
                placeholder: "Select or add medical history",
                theme: "bootstrap4",
                width: '100%' // Ensure full-width styling
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\dentist-crm\resources\views/patient/create.blade.php ENDPATH**/ ?>