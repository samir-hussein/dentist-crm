<?php $__env->startSection('title', 'Treatment Type'); ?>

<?php $__env->startSection('page-path-prefix', 'SETTINGS > '); ?>

<?php $__env->startSection('page-path', 'TREATMENT PLANS'); ?>

<?php $__env->startSection('settings-active', 'active-link'); ?>

<?php $__env->startSection('buttons'); ?>
    <a href="<?php echo e(route('treatment-types.index')); ?>"><button type="button" class="btn btn-dark"><span
                class="fe fe-arrow-left fe-12 mr-2"></span>Back</button></a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <style>
        .tooth-chart {
            width: 150px;
        }

        .Spots {

            polygon,
            path {
                -webkit-transition: fill 0.25s;
                transition: fill 0.25s;
            }

            polygon:hover,
            polygon:active,
            path:hover,
            path:active {
                fill: #c0bfbf !important;
                cursor: pointer;
            }

            .selected {
                fill: #ffcc00 !important;
            }
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger" role="alert">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('success')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card shadow mb-4">
                <div class="card-body">
                    <form action="<?php echo e(route('treatment-types.update', ['treatment_type' => $data->id])); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('put'); ?>
                        <div class="form-row">
                            <div class="form-group col-12">
                                <label for="multi-select">Diagnosis</label>
                                <select multiple name="diagnosis_ids[]" class="form-control select2-multi"
                                    id="multi-select">
                                    <?php $__currentLoopData = $data->diagnosis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $diagnosis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php echo e(in_array($diagnosis->id, $data->selected_diagnosis) ? 'selected' : ''); ?>

                                            value="<?php echo e($diagnosis->id); ?>"><?php echo e($diagnosis->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['diagnosis_ids'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p style="color: red">* <?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-12">
                                <label for="name">Treatment Name</label>
                                <input type="text" class="form-control" id="name"
                                    value="<?php echo e(old('name') ?? $data->name); ?>" name="name" dir="auto">
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p style="color: red">* <?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="tooth_type">Tooth Type</label>
                            <select id="tooth_type" name="tooth_type" class="form-control">
                                <option value="permanent"
                                    <?php echo e(old('tooth_type') || $data->tooth_type == 'permanent' ? 'selected' : ''); ?>>
                                    Permanent
                                </option>
                                <option value="deciduous"
                                    <?php echo e(old('tooth_type') || $data->tooth_type == 'deciduous' ? 'selected' : ''); ?>>
                                    Deciduous
                                </option>
                            </select>
                            <?php $__errorArgs = ['tooth_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p style="color: red">* <?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label for="need_labs">Need Labs?</label>
                            <select id="need_labs" name="need_labs" class="form-control">
                                <option value="1" <?php echo e(old('need_labs') || $data->need_labs ? 'selected' : ''); ?>>Yes
                                </option>
                                <option <?php echo e(!$data->need_labs ? 'selected' : ''); ?> value="0">No</option>
                            </select>
                            <?php $__errorArgs = ['need_labs'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p style="color: red">* <?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label for="description">Description (optional)</label>
                            <textarea class="form-control" id="description" name="description"><?php echo e(old('description') ?? $data->description); ?></textarea>
                            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p style="color: red">* <?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div>
                            <h4 class="mb-3">Sections</h4>
                            <div id="sections-container">
                                <div class="section mb-5">
                                    <div class="form-row">
                                        <div class="form-group col-md-6">
                                            <label for="sections[0][title]">Section Title</label>
                                            <input type="text" class="form-control" id="sections[0][title]"
                                                name="sections[0][title]"
                                                value="<?php echo e(old('sections.0.title') ?? $data->sections[0]->title); ?>">
                                            <?php $__errorArgs = ['sections.0.title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <p style="color: red">* <?php echo e($message); ?></p>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group col-md-6">
                                            <label for="sections[0][multi_selection]">Multi Selection</label>
                                            <select id="sections[0][multi_selection]" name="sections[0][multi_selection]"
                                                class="form-control">
                                                <option value="1"
                                                    <?php echo e(old('sections.0.multi_selection') || $data->sections[0]->multi_selection ? 'selected' : ''); ?>>
                                                    Yes</option>
                                                <option value="0"
                                                    <?php echo e(!$data->sections[0]->multi_selection ? 'selected' : ''); ?>>
                                                    No</option>
                                            </select>
                                            <?php $__errorArgs = ['sections.0.multi_selection'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <p style="color: red">* <?php echo e($message); ?></p>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <h5 class="mb-3">Attributes</h5>
                                        <div id="attributes-container-0">
                                            <div class="attribute mb-5">
                                                <div class="form-row">
                                                    <div class="form-group col-12">
                                                        <label for="sections[0][attributes][0][name]">Attribute Name</label>
                                                        <input type="text" class="form-control"
                                                            name="sections[0][attributes][0][name]"
                                                            placeholder="Attribute Name"
                                                            value="<?php echo e(old('sections.0.attributes.0.name') ?? $data->sections[0]->attributes[0]->name); ?>">
                                                        <?php $__errorArgs = ['sections.0.attributes.0.name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <p style="color: red">* <?php echo e($message); ?></p>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <h6>Inputs</h6>
                                                    <div id="inputs-container-0-0">
                                                        <?php if($data->sections[0]->attributes[0]->inputs): ?>
                                                            <?php for($i = 0; $i < count($data->sections[0]->attributes[0]->inputs); $i++): ?>
                                                                <div class="form-row">
                                                                    <div class="form-group col-11">
                                                                        <label
                                                                            for="sections[0][attributes][0][inputs][<?php echo e($i); ?>][name]">Input
                                                                            Name</label>
                                                                        <input type="text" class="form-control"
                                                                            name="sections[0][attributes][0][inputs][<?php echo e($i); ?>][name]"
                                                                            value="<?php echo e(old('sections.0.attributes.0.inputs.' . $i . '.name') ?? $data->sections[0]->attributes[0]->inputs[$i]->name); ?>">
                                                                        <?php $__errorArgs = ["sections.0.attributes.0.inputs.$i.name"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                            <p style="color: red">* <?php echo e($message); ?></p>
                                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    </div>
                                                                    <div class="col-1 d-flex align-items-center">
                                                                        <button type="button"
                                                                            class="btn btn-danger btn-sm delete-input-btn">X</button>
                                                                    </div>
                                                                    <?php if($data->tooth_type == 'permanent'): ?>
                                                                        <div class="form-group col-12 col-md-6">
                                                                            <label for="tooths">Adult Tooths</label>
                                                                            <?php if (isset($component)) { $__componentOriginalbd539f6a3bb5df07dafb7ce3b641a763 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbd539f6a3bb5df07dafb7ce3b641a763 = $attributes; } ?>
<?php $component = App\View\Components\ToothChart::resolve(['nameAttr' => 'sections[0][attributes][0][inputs]['.e($i).'][adultTooths]','selectedteeth' => json_encode(
                                                                                    $data->sections[0]->attributes[0]
                                                                                        ->inputs[$i]->adultTooths,
                                                                                )] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('tooth-chart'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\ToothChart::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbd539f6a3bb5df07dafb7ce3b641a763)): ?>
<?php $attributes = $__attributesOriginalbd539f6a3bb5df07dafb7ce3b641a763; ?>
<?php unset($__attributesOriginalbd539f6a3bb5df07dafb7ce3b641a763); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbd539f6a3bb5df07dafb7ce3b641a763)): ?>
<?php $component = $__componentOriginalbd539f6a3bb5df07dafb7ce3b641a763; ?>
<?php unset($__componentOriginalbd539f6a3bb5df07dafb7ce3b641a763); ?>
<?php endif; ?>
                                                                        </div>
                                                                    <?php else: ?>
                                                                        <div class="form-group col-12 col-md-6">
                                                                            <label for="tooths">Child Tooths</label>
                                                                            <?php if (isset($component)) { $__componentOriginal87a6ed2ede604ef19bb892ff794a181b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal87a6ed2ede604ef19bb892ff794a181b = $attributes; } ?>
<?php $component = App\View\Components\ChildToothChart::resolve(['nameAttr' => 'sections[0][attributes][0][inputs]['.e($i).'][childTooths]','selectedteeth' => json_encode(
                                                                                    $data->sections[0]->attributes[0]
                                                                                        ->inputs[$i]->childTooths,
                                                                                )] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('child-tooth-chart'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\ChildToothChart::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal87a6ed2ede604ef19bb892ff794a181b)): ?>
<?php $attributes = $__attributesOriginal87a6ed2ede604ef19bb892ff794a181b; ?>
<?php unset($__attributesOriginal87a6ed2ede604ef19bb892ff794a181b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal87a6ed2ede604ef19bb892ff794a181b)): ?>
<?php $component = $__componentOriginal87a6ed2ede604ef19bb892ff794a181b; ?>
<?php unset($__componentOriginal87a6ed2ede604ef19bb892ff794a181b); ?>
<?php endif; ?>
                                                                        </div>
                                                                    <?php endif; ?>
                                                                </div>
                                                            <?php endfor; ?>
                                                        <?php endif; ?>
                                                    </div>
                                                    <button type="button" data-attribute="0" data-section="0"
                                                        data-input="<?php echo e($i); ?>"
                                                        class="add-input-btn btn btn-info">Add
                                                        Input</button>
                                                </div>
                                            </div>

                                            <?php if(count($data->sections[0]->attributes) > 0): ?>
                                                <?php for($a = 1; $a < count($data->sections[0]->attributes); $a++): ?>
                                                    <div class="attribute mb-5">
                                                        <div class="form-row">
                                                            <div class="form-group col-12">
                                                                <label
                                                                    for="sections[0][attributes][<?php echo e($a); ?>][name]">Attribute
                                                                    Name</label>
                                                                <input type="text" class="form-control"
                                                                    name="sections[0][attributes][<?php echo e($a); ?>][name]"
                                                                    placeholder="Attribute Name"
                                                                    value="<?php echo e(old('sections.0.attributes.' . $a . '.name') ?? $data->sections[0]->attributes[$a]->name); ?>">
                                                                <?php $__errorArgs = ['sections.0.attributes.' . $a . '.name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                    <p style="color: red">* <?php echo e($message); ?></p>
                                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <h6>Inputs</h6>
                                                            <div id="inputs-container-0-<?php echo e($a); ?>">
                                                                <?php if($data->sections[0]->attributes[$a]->inputs): ?>
                                                                    <?php for($i = 0; $i < count($data->sections[0]->attributes[$a]->inputs); $i++): ?>
                                                                        <div class="form-row">
                                                                            <div class="form-group col-11">
                                                                                <label
                                                                                    for="sections[0][attributes][<?php echo e($a); ?>][inputs][<?php echo e($i); ?>][name]">Input
                                                                                    Name</label>
                                                                                <input type="text" class="form-control"
                                                                                    name="sections[0][attributes][<?php echo e($a); ?>][inputs][<?php echo e($i); ?>][name]"
                                                                                    value="<?php echo e(old('sections.0.attributes.' . $a . '.inputs.' . $i . '.name') ?? $data->sections[0]->attributes[$a]->inputs[$i]->name); ?>">
                                                                                <?php $__errorArgs = ["sections.0.attributes.$a.inputs.$i.name"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                    <p style="color: red">*
                                                                                        <?php echo e($message); ?></p>
                                                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                            </div>

                                                                            <div class="col-1 d-flex align-items-center">
                                                                                <button type="button"
                                                                                    class="btn btn-danger btn-sm delete-input-btn">X</button>
                                                                            </div>

                                                                            <?php if($data->tooth_type == 'permanent'): ?>
                                                                                <div class="form-group col-12 col-md-6">
                                                                                    <label for="tooths">Adult
                                                                                        Tooths</label>
                                                                                    <?php if (isset($component)) { $__componentOriginalbd539f6a3bb5df07dafb7ce3b641a763 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbd539f6a3bb5df07dafb7ce3b641a763 = $attributes; } ?>
<?php $component = App\View\Components\ToothChart::resolve(['nameAttr' => 'sections[0][attributes]['.e($a).'][inputs]['.e($i).'][adultTooths]','selectedteeth' => json_encode(
                                                                                            $data->sections[0]
                                                                                                ->attributes[$a]
                                                                                                ->inputs[$i]
                                                                                                ->adultTooths,
                                                                                        )] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('tooth-chart'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\ToothChart::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbd539f6a3bb5df07dafb7ce3b641a763)): ?>
<?php $attributes = $__attributesOriginalbd539f6a3bb5df07dafb7ce3b641a763; ?>
<?php unset($__attributesOriginalbd539f6a3bb5df07dafb7ce3b641a763); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbd539f6a3bb5df07dafb7ce3b641a763)): ?>
<?php $component = $__componentOriginalbd539f6a3bb5df07dafb7ce3b641a763; ?>
<?php unset($__componentOriginalbd539f6a3bb5df07dafb7ce3b641a763); ?>
<?php endif; ?>
                                                                                </div>
                                                                            <?php else: ?>
                                                                                <div class="form-group col-12 col-md-6">
                                                                                    <label for="tooths">Child
                                                                                        Tooths</label>
                                                                                    <?php if (isset($component)) { $__componentOriginal87a6ed2ede604ef19bb892ff794a181b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal87a6ed2ede604ef19bb892ff794a181b = $attributes; } ?>
<?php $component = App\View\Components\ChildToothChart::resolve(['nameAttr' => 'sections[0][attributes]['.e($a).'][inputs]['.e($i).'][childTooths]','selectedteeth' => json_encode(
                                                                                            $data->sections[0]
                                                                                                ->attributes[$a]
                                                                                                ->inputs[$i]
                                                                                                ->childTooths,
                                                                                        )] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('child-tooth-chart'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\ChildToothChart::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal87a6ed2ede604ef19bb892ff794a181b)): ?>
<?php $attributes = $__attributesOriginal87a6ed2ede604ef19bb892ff794a181b; ?>
<?php unset($__attributesOriginal87a6ed2ede604ef19bb892ff794a181b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal87a6ed2ede604ef19bb892ff794a181b)): ?>
<?php $component = $__componentOriginal87a6ed2ede604ef19bb892ff794a181b; ?>
<?php unset($__componentOriginal87a6ed2ede604ef19bb892ff794a181b); ?>
<?php endif; ?>
                                                                                </div>
                                                                            <?php endif; ?>
                                                                        </div>
                                                                    <?php endfor; ?>
                                                                <?php endif; ?>
                                                            </div>
                                                            <button type="button" data-attribute="<?php echo e($a); ?>"
                                                                data-section="0" data-input="<?php echo e($i); ?>"
                                                                class="add-input-btn btn btn-info">Add
                                                                Input</button>
                                                            <button type="button"
                                                                class="delete-attribute-btn btn btn-danger">Remove
                                                                Attribute</button>
                                                        </div>
                                                    </div>
                                                <?php endfor; ?>
                                            <?php endif; ?>
                                        </div>
                                        <button type="button" data-attribute="<?php echo e($a); ?>" data-section="0"
                                            class="add-attribute-btn btn btn-dark">Add Another
                                            Attribute</button>
                                    </div>
                                </div>

                                <?php if(count($data->sections) > 0): ?>
                                    <?php for($i = 1; $i < count($data->sections); $i++): ?>
                                        <div class="section mb-5">
                                            <div class="form-row">
                                                <div class="form-group col-md-6">
                                                    <label for="sections[<?php echo e($i); ?>][title]">Section
                                                        Title</label>
                                                    <input type="text" class="form-control"
                                                        id="sections[<?php echo e($i); ?>][title]"
                                                        name="sections[<?php echo e($i); ?>][title]"
                                                        value="<?php echo e(old('sections.' . $i . '.title') ?? $data->sections[$i]->title); ?>">
                                                    <?php $__errorArgs = ["sections.$i.title"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <p style="color: red">* <?php echo e($message); ?></p>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                                <div class="form-group col-md-6">
                                                    <label for="sections[<?php echo e($i); ?>][multi_selection]">Multi
                                                        Selection</label>
                                                    <select id="sections[<?php echo e($i); ?>][multi_selection]"
                                                        name="sections[<?php echo e($i); ?>][multi_selection]"
                                                        class="form-control">
                                                        <option value="1"
                                                            <?php echo e(old('sections.' . $i . '.multi_selection') || $data->sections[$i]->multi_selection ? 'selected' : ''); ?>>
                                                            Yes</option>
                                                        <option value="0"
                                                            <?php echo e(!$data->sections[$i]->multi_selection ? 'selected' : ''); ?>>
                                                            No</option>
                                                    </select>
                                                    <?php $__errorArgs = ["sections.$i.multi_selection"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <p style="color: red">* <?php echo e($message); ?></p>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>

                                            <div class="form-group">
                                                <h5 class="mb-3">Attributes</h5>
                                                <div id="attributes-container-<?php echo e($i); ?>">
                                                    <div class="attribute mb-5">
                                                        <div class="form-row">
                                                            <div class="form-group col-12">
                                                                <label
                                                                    for="sections[<?php echo e($i); ?>][attributes][0][name]">Attribute
                                                                    Name</label>
                                                                <input type="text" class="form-control"
                                                                    name="sections[<?php echo e($i); ?>][attributes][0][name]"
                                                                    placeholder="Attribute Name"
                                                                    value="<?php echo e(old('sections.' . $i . '.attributes.0.name') ?? $data->sections[$i]->attributes[0]->name); ?>">
                                                                <?php $__errorArgs = ['sections.' . $i . '.attributes.0.name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                    <p style="color: red">* <?php echo e($message); ?></p>
                                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <h6>Inputs</h6>
                                                            <div id="inputs-container-<?php echo e($i); ?>-0">
                                                                <?php if($data->sections[$i]->attributes[0]->inputs): ?>
                                                                    <?php for($j = 0; $j < count($data->sections[$i]->attributes[0]->inputs); $j++): ?>
                                                                        <div class="form-row">
                                                                            <div class="form-group col-11">
                                                                                <label
                                                                                    for="sections[<?php echo e($i); ?>][attributes][0][inputs][<?php echo e($j); ?>][name]">Input
                                                                                    Name</label>
                                                                                <input type="text" class="form-control"
                                                                                    name="sections[<?php echo e($i); ?>][attributes][0][inputs][<?php echo e($j); ?>][name]"
                                                                                    value="<?php echo e(old('sections.' . $i . '.attributes.0.inputs.' . $j . '.name') ?? $data->sections[$i]->attributes[0]->inputs[$j]->name); ?>">
                                                                                <?php $__errorArgs = ["sections.$i.attributes.0.inputs.$j.name"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                    <p style="color: red">*
                                                                                        <?php echo e($message); ?></p>
                                                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                            </div>

                                                                            <div class="col-1 d-flex align-items-center">
                                                                                <button type="button"
                                                                                    class="btn btn-danger btn-sm delete-input-btn">X</button>
                                                                            </div>

                                                                            <?php if($data->tooth_type == 'permanent'): ?>
                                                                                <div class="form-group col-12 col-md-6">
                                                                                    <label for="tooths">Adult
                                                                                        Tooths</label>
                                                                                    <?php if (isset($component)) { $__componentOriginalbd539f6a3bb5df07dafb7ce3b641a763 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbd539f6a3bb5df07dafb7ce3b641a763 = $attributes; } ?>
<?php $component = App\View\Components\ToothChart::resolve(['nameAttr' => 'sections['.e($i).'][attributes][0][inputs]['.e($j).'][adultTooths]','selectedteeth' => json_encode(
                                                                                            $data->sections[$i]
                                                                                                ->attributes[0]->inputs[
                                                                                                $j
                                                                                            ]->adultTooths,
                                                                                        )] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('tooth-chart'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\ToothChart::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbd539f6a3bb5df07dafb7ce3b641a763)): ?>
<?php $attributes = $__attributesOriginalbd539f6a3bb5df07dafb7ce3b641a763; ?>
<?php unset($__attributesOriginalbd539f6a3bb5df07dafb7ce3b641a763); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbd539f6a3bb5df07dafb7ce3b641a763)): ?>
<?php $component = $__componentOriginalbd539f6a3bb5df07dafb7ce3b641a763; ?>
<?php unset($__componentOriginalbd539f6a3bb5df07dafb7ce3b641a763); ?>
<?php endif; ?>
                                                                                </div>
                                                                            <?php else: ?>
                                                                                <div class="form-group col-12 col-md-6">
                                                                                    <label for="tooths">Child
                                                                                        Tooths</label>
                                                                                    <?php if (isset($component)) { $__componentOriginal87a6ed2ede604ef19bb892ff794a181b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal87a6ed2ede604ef19bb892ff794a181b = $attributes; } ?>
<?php $component = App\View\Components\ChildToothChart::resolve(['nameAttr' => 'sections['.e($i).'][attributes][0][inputs]['.e($j).'][childTooths]','selectedteeth' => json_encode(
                                                                                            $data->sections[$i]
                                                                                                ->attributes[0]->inputs[
                                                                                                $j
                                                                                            ]->childTooths,
                                                                                        )] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('child-tooth-chart'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\ChildToothChart::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal87a6ed2ede604ef19bb892ff794a181b)): ?>
<?php $attributes = $__attributesOriginal87a6ed2ede604ef19bb892ff794a181b; ?>
<?php unset($__attributesOriginal87a6ed2ede604ef19bb892ff794a181b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal87a6ed2ede604ef19bb892ff794a181b)): ?>
<?php $component = $__componentOriginal87a6ed2ede604ef19bb892ff794a181b; ?>
<?php unset($__componentOriginal87a6ed2ede604ef19bb892ff794a181b); ?>
<?php endif; ?>
                                                                                </div>
                                                                            <?php endif; ?>
                                                                        </div>
                                                                    <?php endfor; ?>
                                                                <?php endif; ?>
                                                            </div>
                                                            <button type="button" data-attribute="0"
                                                                data-section="<?php echo e($i); ?>"
                                                                data-input="<?php echo e($j); ?>"
                                                                class="add-input-btn btn btn-info">Add
                                                                Input</button>
                                                        </div>
                                                    </div>

                                                    <?php if(count($data->sections[$i]->attributes) > 0): ?>
                                                        <?php for($a = 1; $a < count($data->sections[$i]->attributes); $a++): ?>
                                                            <div class="attribute mb-5">
                                                                <div class="form-row">
                                                                    <div class="form-group col-12">
                                                                        <label
                                                                            for="sections[<?php echo e($i); ?>][attributes][<?php echo e($a); ?>][name]">Attribute
                                                                            Name</label>
                                                                        <input type="text" class="form-control"
                                                                            name="sections[<?php echo e($i); ?>][attributes][<?php echo e($a); ?>][name]"
                                                                            placeholder="Attribute Name"
                                                                            value="<?php echo e(old('sections.' . $i . '.attributes.' . $a . '.name') ?? $data->sections[$i]->attributes[$a]->name); ?>">
                                                                        <?php $__errorArgs = ['sections.' . $i . '.attributes.' . $a .
                                                                            '.name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                            <p style="color: red">* <?php echo e($message); ?></p>
                                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    </div>
                                                                </div>
                                                                <div class="form-group">
                                                                    <h6>Inputs</h6>
                                                                    <div
                                                                        id="inputs-container-<?php echo e($i); ?>-<?php echo e($a); ?>">
                                                                        <?php if($data->sections[$i]->attributes[$a]->inputs): ?>
                                                                            <?php for($j = 0; $j < count($data->sections[$i]->attributes[$a]->inputs); $j++): ?>
                                                                                <div class="form-row">
                                                                                    <div class="form-group col-11">
                                                                                        <label
                                                                                            for="sections[<?php echo e($i); ?>][attributes][<?php echo e($a); ?>][inputs][<?php echo e($j); ?>][name]">Input
                                                                                            Name</label>
                                                                                        <input type="text"
                                                                                            class="form-control"
                                                                                            name="sections[<?php echo e($i); ?>][attributes][<?php echo e($a); ?>][inputs][<?php echo e($j); ?>][name]"
                                                                                            value="<?php echo e(old('sections.' . $i . '.attributes.' . $a . '.inputs.' . $j . '.name') ?? $data->sections[$i]->attributes[$a]->inputs[$j]->name); ?>">
                                                                                        <?php $__errorArgs = ["sections.$i.attributes.$a.inputs.$j.name"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                            <p style="color: red">*
                                                                                                <?php echo e($message); ?></p>
                                                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                                    </div>

                                                                                    <div
                                                                                        class="col-1 d-flex align-items-center">
                                                                                        <button type="button"
                                                                                            class="btn btn-danger btn-sm delete-input-btn">X</button>
                                                                                    </div>

                                                                                    <?php if($data->tooth_type == 'permanent'): ?>
                                                                                        <div
                                                                                            class="form-group col-12 col-md-6">
                                                                                            <label for="tooths">Adult
                                                                                                Tooths</label>
                                                                                            <?php if (isset($component)) { $__componentOriginalbd539f6a3bb5df07dafb7ce3b641a763 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbd539f6a3bb5df07dafb7ce3b641a763 = $attributes; } ?>
<?php $component = App\View\Components\ToothChart::resolve(['nameAttr' => 'sections['.e($i).'][attributes]['.e($a).'][inputs]['.e($j).'][adultTooths]','selectedteeth' => json_encode(
                                                                                                    $data->sections[$i]
                                                                                                        ->attributes[$a]
                                                                                                        ->inputs[$j]
                                                                                                        ->adultTooths,
                                                                                                )] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('tooth-chart'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\ToothChart::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbd539f6a3bb5df07dafb7ce3b641a763)): ?>
<?php $attributes = $__attributesOriginalbd539f6a3bb5df07dafb7ce3b641a763; ?>
<?php unset($__attributesOriginalbd539f6a3bb5df07dafb7ce3b641a763); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbd539f6a3bb5df07dafb7ce3b641a763)): ?>
<?php $component = $__componentOriginalbd539f6a3bb5df07dafb7ce3b641a763; ?>
<?php unset($__componentOriginalbd539f6a3bb5df07dafb7ce3b641a763); ?>
<?php endif; ?>
                                                                                        </div>
                                                                                    <?php else: ?>
                                                                                        <div
                                                                                            class="form-group col-12 col-md-6">
                                                                                            <label for="tooths">Child
                                                                                                Tooths</label>
                                                                                            <?php if (isset($component)) { $__componentOriginal87a6ed2ede604ef19bb892ff794a181b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal87a6ed2ede604ef19bb892ff794a181b = $attributes; } ?>
<?php $component = App\View\Components\ChildToothChart::resolve(['nameAttr' => 'sections['.e($i).'][attributes]['.e($a).'][inputs]['.e($j).'][childTooths]','selectedteeth' => json_encode(
                                                                                                    $data->sections[$i]
                                                                                                        ->attributes[$a]
                                                                                                        ->inputs[$j]
                                                                                                        ->childTooths,
                                                                                                )] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('child-tooth-chart'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\ChildToothChart::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal87a6ed2ede604ef19bb892ff794a181b)): ?>
<?php $attributes = $__attributesOriginal87a6ed2ede604ef19bb892ff794a181b; ?>
<?php unset($__attributesOriginal87a6ed2ede604ef19bb892ff794a181b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal87a6ed2ede604ef19bb892ff794a181b)): ?>
<?php $component = $__componentOriginal87a6ed2ede604ef19bb892ff794a181b; ?>
<?php unset($__componentOriginal87a6ed2ede604ef19bb892ff794a181b); ?>
<?php endif; ?>
                                                                                        </div>
                                                                                    <?php endif; ?>
                                                                                </div>
                                                                            <?php endfor; ?>
                                                                        <?php endif; ?>
                                                                    </div>
                                                                    <button type="button"
                                                                        data-attribute="<?php echo e($a); ?>"
                                                                        data-section="<?php echo e($i); ?>"
                                                                        data-input="<?php echo e($j); ?>"
                                                                        class="add-input-btn btn btn-info">Add
                                                                        Input</button>
                                                                    <button type="button"
                                                                        class="delete-attribute-btn btn btn-danger">Remove
                                                                        Attribute</button>
                                                                </div>
                                                            </div>
                                                        <?php endfor; ?>
                                                    <?php endif; ?>
                                                </div>
                                                <button type="button" data-attribute="<?php echo e($a); ?>"
                                                    data-section="<?php echo e($i); ?>"
                                                    class="add-attribute-btn btn btn-dark">Add Another
                                                    Attribute</button>
                                                <button type="button" class="delete-section-btn btn btn-danger">Remove
                                                    Section</button>
                                            </div>
                                        </div>
                                    <?php endfor; ?>
                                <?php endif; ?>
                            </div>
                            <button type="button" data-section="<?php echo e($i); ?>"
                                class="add-section-btn btn btn-warning mb-2">Add
                                Another
                                Section</button>
                        </div>

                        <button type="submit" class="btn btn-primary">Save</button>
                    </form>
                </div> <!-- /. card-body -->
            </div> <!-- /. card -->
        </div> <!-- /. col -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).on('click', ".add-section-btn", function() {
            const section = $(this).data('section');
            $("#sections-container").append(
                `<div class="section mb-5">
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="sections[${section}][title]">Section Title</label>
                            <input type="text" class="form-control" id="sections[${section}][title]"
                                name="sections[${section}][title]" value="<?php echo e(old('sections.${section}.title')); ?>">
                            <?php $__errorArgs = ['sections.${section}.title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p style="color: red">* <?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="sections[${section}][multi_selection]">Multi Selection</label>
                            <select id="sections[${section}][multi_selection]" name="sections[${section}][multi_selection]"
                                class="form-control">
                                <option value="1"
                                    <?php echo e(old('sections.${section}.multi_selection') ? 'selected' : ''); ?>>Yes</option>
                                <option value="0"
                                    <?php echo e(!old('sections.${section}.multi_selection') ? 'selected' : ''); ?>>No</option>
                            </select>
                            <?php $__errorArgs = ['sections.${section}.multi_selection'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p style="color: red">* <?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="form-group">
                        <h5 class="mb-3">Attributes</h5>
                        <div id="attributes-container-${section}">
                            <div class="attribute mb-5">
                                <div class="form-row">
                                    <div class="form-group col-12">
                                        <label for="sections[${section}][attributes][0][name]">Attribute Name</label>
                                        <input type="text" class="form-control"
                                            name="sections[${section}][attributes][0][name]"
                                            placeholder="Attribute Name"
                                            value="<?php echo e(old('sections.${section}.attributes.0.name')); ?>">
                                        <?php $__errorArgs = ['sections.${section}.attributes.0.name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <p style="color: red">* <?php echo e($message); ?></p>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <h6>Inputs</h6>
                                    <div id="inputs-container-${section}-0">

                                    </div>
                                    <button type="button" data-attribute="0" data-section="${section}"
                                        data-input="0" class="add-input-btn btn btn-info">Add
                                        Input</button>
                                </div>
                            </div>
                        </div>
                        <button type="button" data-attribute="1" data-section="${section}"
                            class="add-attribute-btn btn btn-dark">Add Another
                            Attribute</button>
                             <button type="button"
                            class="delete-section-btn btn btn-danger">Remove Section</button>
                    </div>
                </div>`);

            $(this).data("section", section + 1);
        })

        $(document).on("click", ".add-attribute-btn", function() {
            const attribute = $(this).data('attribute');
            const section = $(this).data('section');
            $("#attributes-container-" + section).append(`<div class="attribute mb-5">
                                            <div class="form-row">
                                                <div class="form-group col-12">
                                                    <label for="sections[${section}][attributes][${attribute}][name]">Attribute Name</label>
                                                    <input type="text" class="form-control"
                                                        name="sections[${section}][attributes][${attribute}][name]" placeholder="Attribute Name"
                                                        value="<?php echo e(old('sections.${section}.attributes.${attribute}.name')); ?>">
                                                    <?php $__errorArgs = ['sections.${section}.attributes.${attribute}.name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <p style="color: red">* <?php echo e($message); ?></p>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <h6>Inputs</h6>
                                                <div id="inputs-container-${section}-${attribute}">

                                                </div>
                                                <button type="button" data-attribute="${attribute}" data-section="${section}" data-input="0"
                                                    class="add-input-btn btn btn-info">Add
                                                    Input</button>

                                                    <button type="button" class="delete-attribute-btn btn btn-danger">Remove Attribute</button>
                                            </div>
                                        </div>`);
            $(this).data("attribute", attribute + 1);
        })

        $(document).on('click', ".add-input-btn", function() {
            const attribute = $(this).data('attribute');
            const section = $(this).data('section');
            const input = $(this).data('input');
            let tooth_type = $("#tooth_type").val();
            let append = `<div class="form-row">
                <div class="form-group col-11">
                    <label for="sections[${section}][attributes][${attribute}][inputs][${input}][name]">Input Name</label>
                    <input type="text" class="form-control"
                        name="sections[${section}][attributes][${attribute}][inputs][${input}][name]"
                        value="<?php echo e(old('sections.${section}.attributes.${attribute}.inputs.${input}.name')); ?>">
                    <?php $__errorArgs = ['sections.${section}.attributes.${attribute}.inputs.${input}.name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p style="color: red">* <?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-1 d-flex align-items-center">
                    <button type="button"
                        class="btn btn-danger btn-sm delete-input-btn">X</button>
                </div>`;

            if (tooth_type == "permanent") {
                append += `<div class="form-group col-12 col-md-6">
                    <label for="tooths">Adult Tooths</label>
                    <?php if (isset($component)) { $__componentOriginalbd539f6a3bb5df07dafb7ce3b641a763 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbd539f6a3bb5df07dafb7ce3b641a763 = $attributes; } ?>
<?php $component = App\View\Components\ToothChart::resolve(['nameAttr' => 'sections[${section}][attributes][${attribute}][inputs][${input}][adultTooths]'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('tooth-chart'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\ToothChart::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbd539f6a3bb5df07dafb7ce3b641a763)): ?>
<?php $attributes = $__attributesOriginalbd539f6a3bb5df07dafb7ce3b641a763; ?>
<?php unset($__attributesOriginalbd539f6a3bb5df07dafb7ce3b641a763); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbd539f6a3bb5df07dafb7ce3b641a763)): ?>
<?php $component = $__componentOriginalbd539f6a3bb5df07dafb7ce3b641a763; ?>
<?php unset($__componentOriginalbd539f6a3bb5df07dafb7ce3b641a763); ?>
<?php endif; ?>
                </div></div>`;
            } else {
                append += `<div class="form-group col-12 col-md-6">
                    <label for="tooths">Child Tooths</label>
                    <?php if (isset($component)) { $__componentOriginal87a6ed2ede604ef19bb892ff794a181b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal87a6ed2ede604ef19bb892ff794a181b = $attributes; } ?>
<?php $component = App\View\Components\ChildToothChart::resolve(['nameAttr' => 'sections[${section}][attributes][${attribute}][inputs][${input}][childTooths]'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('child-tooth-chart'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\ChildToothChart::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal87a6ed2ede604ef19bb892ff794a181b)): ?>
<?php $attributes = $__attributesOriginal87a6ed2ede604ef19bb892ff794a181b; ?>
<?php unset($__attributesOriginal87a6ed2ede604ef19bb892ff794a181b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal87a6ed2ede604ef19bb892ff794a181b)): ?>
<?php $component = $__componentOriginal87a6ed2ede604ef19bb892ff794a181b; ?>
<?php unset($__componentOriginal87a6ed2ede604ef19bb892ff794a181b); ?>
<?php endif; ?>
                </div></div>`;
            }

            $("#inputs-container-" + section + "-" + attribute).append(append);

            $(this).data("input", input + 1);
        })

        $(document).on('click', ".delete-input-btn", function() {
            $(this).closest('.form-row').remove();
        })

        $(document).on('click', ".delete-attribute-btn", function() {
            $(this).closest('.attribute').remove();
        })

        $(document).on('click', ".delete-section-btn", function() {
            $(this).closest('.section').remove();
        })
    </script>

    <script>
        $(document).ready(function() {
            // Event listener for selecting/deselecting a tooth
            $(document).on("click", "polygon, path", function() {
                const toothNumber = $(this).data("key"); // Get the data-key attribute (tooth number)
                const toothType = $(this).data("tooth");

                // Ensure the toothNumber is defined before processing
                if (toothNumber !== undefined) {
                    let closestToothChart = $(this).closest('.tooth-chart');

                    // Get or initialize the array of selected teeth for this specific chart
                    let selectedTeeth = closestToothChart.data('selectedteeth') || [];

                    if ($(this).hasClass("selected")) {
                        // If the tooth is already selected, remove it from the array
                        selectedTeeth = selectedTeeth.filter(t => t != toothNumber);
                    } else {
                        // If it's not selected, add it to the array
                        selectedTeeth.push(toothNumber);
                    }

                    // Update the data-tooth attribute in the closestToothChart to store the updated array
                    closestToothChart.data('selectedteeth', selectedTeeth);

                    // Toggle the selected class to change the color
                    $(this).toggleClass("selected");

                    updateInput(closestToothChart, selectedTeeth);
                }
            });

            // Function to mark selected teeth based on the data-selectedTeeth attribute
            $('.tooth-chart').each(function() {
                const closestToothChart = $(this);
                const selectedTeeth = closestToothChart.data('selectedteeth') || [];

                // Mark the selected teeth based on the selectedTeeth array
                selectedTeeth.forEach(tooth => {
                    closestToothChart.find(
                        `polygon[data-key='${tooth}'], path[data-key='${tooth}']`).addClass(
                        'selected');
                });

                updateInput(closestToothChart, selectedTeeth);
            });

            function updateInput(closestToothChart, selectedTeeth) {
                let dataId = closestToothChart.data("id");

                const closestHiddenInputs = closestToothChart.prev('.hidden-tooth-inputs');

                // Clear the closest hidden inputs container
                closestHiddenInputs.empty();

                // Append hidden inputs for the selected teeth
                selectedTeeth.forEach(tooth => {
                    closestHiddenInputs.append(
                        `<input type="hidden" name="${dataId}[]" value="${tooth}">`
                    );
                });
            }
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\dentist-crm\resources\views/treatmentType/edit.blade.php ENDPATH**/ ?>