<?php $__env->startSection('title', 'Prescription'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card shadow mb-4">
                <div class="card-body">

                    <div class="form-row">
                        <div class="form-group col-12">
                            <label>Patient</label>
                            <select class="form-control select2" name="patient">
                                <?php $__currentLoopData = $data->patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($patient->name); ?>">#<?php echo e($patient->code); ?> |
                                        <?php echo e($patient->name); ?> |
                                        <?php echo e($patient->phone); ?> | <?php echo e($patient->phone2); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div> <!-- form-group -->
                    </div>

                    <div class="form-row">
                        <div class="form-group col-12">
                            <label>Diagnose</label>
                            <select class="form-control select2" name="diagnose">
                                <?php $__currentLoopData = $data->diagnosis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $diagnose): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($diagnose); ?>">
                                        <?php echo e($diagnose); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div> <!-- form-group -->
                    </div>

                    <div id="medicines">
                        <div class="form-row">
                            <div class="form-group col-md-4">
                                <label>Type</label>
                                <select class="types form-control select2" name="patient_id">
                                    <?php $__currentLoopData = $data->medicines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medicine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($medicine->name); ?>"
                                            data-medicines="<?php echo e(json_encode($medicine->medicine)); ?>">
                                            <?php echo e($medicine->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group col-md-4">
                                <label>Medicine</label>
                                <select class="form-control select2 medicines-options" name="medicines">
                                    <?php $__currentLoopData = $data->medicines[0]->medicine; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medicine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($medicine); ?>">
                                            <?php echo e($medicine); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group col-md-4">
                                <label>Dose</label>
                                <select class="form-control select2 dose" name="doses">
                                    <?php $__currentLoopData = $data->doses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dose): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($dose); ?>">
                                            <?php echo e($dose); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>

                    </div>
                    <div class="mb-2">
                        <button type="button" id="add-medicine" class="btn btn-warning">Add Medicine</button>
                    </div>
                    <div id="print-area" style="display:none">
                        <table style="width: 80%; margin-top:110px">
                            <tbody>
                                <tr>
                                    <td style="padding-bottom: 15px;font-size: 19px;font-family: cursive">Date</td>
                                    <td style="padding-bottom: 15px;font-size: 19px;font-family: cursive">:</td>
                                    <td style="padding-bottom: 15px;font-size: 19px;font-family: cursive">
                                        <?php echo e(date('d-m-Y')); ?></td>
                                </tr>
                                <tr>
                                    <td style="padding-bottom: 15px;font-size: 19px;font-family: cursive">Name</td>
                                    <td style="padding-bottom: 15px;font-size: 19px;font-family: cursive">:</td>
                                    <td style="padding-bottom: 15px;font-size: 19px;font-family: cursive"
                                        id="print-patient-name"></td>
                                </tr>
                                <tr>
                                    <td style="padding-bottom: 15px;font-size: 19px;font-family: cursive">Diagnosis</td>
                                    <td style="padding-bottom: 15px;font-size: 19px;font-family: cursive">:</td>
                                    <td style="padding-bottom: 15px;font-size: 19px;font-family: cursive"
                                        id="print-diagnosis"></td>
                                </tr>
                                <tr>
                                    <td style="font-size: 60px;font-family:cursive;font-weight:bolder">R/</td>
                                </tr>
                            </tbody>
                        </table>
                        <table style="width: 85%;margin:auto;margin-top:15px">
                            <tbody id="print-medicines-list">

                            </tbody>
                        </table>
                    </div>
                    <button type="button" id="generate-print" class="btn btn-primary">Print</button>
                </div> <!-- /. card-body -->
            </div> <!-- /. card -->
        </div> <!-- /. col -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).on("change", ".types", function() {
            // Get the selected option
            let selectedOption = $(this).find('option:selected');

            // Get the data-medicines attribute as a JSON object
            let medicinesData = selectedOption.data('medicines');

            let html = "";

            medicinesData.forEach(function(medicine) {
                html += `<option value="${medicine}">${medicine}</option>`;
            });

            $(this).closest('.form-row').find(".medicines-options").html(html);
        })

        $(document).on("click", ".del-med", function() {
            $(this).closest('.form-row').remove();
        })

        $("#add-medicine").click(function() {
            $("#medicines").append(`
                 <div class="form-row">
                            <div class="form-group col-md-4">
                                <label>Type</label>
                                <select class="types form-control select2" name="patient_id">
                                    <?php $__currentLoopData = $data->medicines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medicine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($medicine->name); ?>"
                                            data-medicines="<?php echo e(json_encode($medicine->medicine)); ?>">
                                            <?php echo e($medicine->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group col-md-4">
                                <label>Medicine</label>
                                <select class="form-control medicines-options select2" name="medicines">
                                    <?php $__currentLoopData = $data->medicines[0]->medicine; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medicine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($medicine); ?>">
                                            <?php echo e($medicine); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group col-md-4">
                                <label>Dose</label>
                                <select class="form-control select2 dose" name="doses">
                                    <?php $__currentLoopData = $data->doses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dose): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($dose); ?>">
                                            <?php echo e($dose); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group col-md-1">
                                <button type="button" class="del-med btn btn-danger">remove</button>
                                </div>
                        </div>
            `);
        });

        $(document).ready(function() {
            $("#generate-print").click(function() {
                // Gather data for printing
                const patientName = $("select[name='patient'] option:selected").val().trim();
                const diagnosis = $("select[name='diagnose']").find('option:selected').text()
                    .trim(); // Diagnose select

                // Fill in data in print section
                $("#print-patient-name").text(patientName);
                $("#print-diagnosis").text(diagnosis);

                // Medicines and doses
                let medicineList = "";
                $("#medicines .form-row").each(function() {
                    const medicine = $(this).find(".medicines-options option:selected").text()
                        .trim();
                    const dose = $(this).find(".dose option:selected").text().trim();
                    medicineList +=
                        `<tr><td style="padding-bottom: 15px;font-size: 19px;font-family: cursive">${medicine}</td><td style="font-size: 19px;font-family: cursive"> ${dose}</td></tr>`;
                });
                $("#print-medicines-list").html(medicineList);

                // Create an iFrame for printing
                let printWindow = window.open('', '_blank', 'width=1200,height=600');
                printWindow.document.write(`
                <html>
                <head></head>
                <body>${document.getElementById("print-area").innerHTML}</body>
                </html>
            `);
                printWindow.document.close(); // Finish writing to iFrame
                printWindow.focus();
                printWindow.print();
                printWindow.onafterprint = function() {
                    printWindow.close();
                };
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\dentist-crm\resources\views/prescription.blade.php ENDPATH**/ ?>