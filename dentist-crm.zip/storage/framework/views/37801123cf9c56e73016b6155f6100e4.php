<?php if(count($panorama) > 0): ?>
    <?php $__currentLoopData = $panorama; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="panorama<?php echo e($img['id']); ?>" tabindex="-1" role="dialog"
            aria-labelledby="mySmallModalLabel" aria-hidden="true">
            <button aria-label="" type="button" class="close px-2" data-dismiss="modal" aria-hidden="true">
                <span aria-hidden="true">×</span>
            </button>
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-body text-center">
                        <img src="<?php echo e($img['url']); ?>" alt="">
                    </div>
                    <button class="btn btn-danger del-tooth" data-id="<?php echo e($img['id']); ?>">Delete</button>
                </div>
            </div>
        </div> <!-- small modal -->
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php /**PATH D:\dentist-crm\resources\views/ajax-components/tooth-panorama-modals.blade.php ENDPATH**/ ?>