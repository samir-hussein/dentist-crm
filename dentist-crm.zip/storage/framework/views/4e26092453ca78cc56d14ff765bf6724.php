<?php $__env->startSection('settings-active', 'active-link'); ?>

<?php $__env->startSection('page-path', 'SETTINGS > SCHEDULE'); ?>

<?php $__env->startSection('buttons'); ?>
    <a href="<?php echo e(route('settings')); ?>"><button type="button" class="btn btn-dark"><span
                class="fe fe-arrow-left fe-12 mr-2"></span>Back</button></a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <style>
        a,
        a:hover {
            color: inherit;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row align-items-center">
        <div class="col-6 text-center">
            <div>
                <a href="<?php echo e(route('schdule-days.index')); ?>"
                    class="squircle bg-danger justify-content-center text-decoration-none">
                    <i class="fe fe-calendar fe-32 align-self-center text-white"></i>
                </a>
            </div>
            <a href="<?php echo e(route('schdule-days.index')); ?>" class="text-decoration-none">
                <p>Schedule Days</p>
            </a>
        </div>
        <div class="col-6 text-center">
            <div>
                <a href="<?php echo e(route('schdule-dates.index')); ?>"
                    class="squircle bg-success justify-content-center text-decoration-none">
                    <i class="fe fe-clock fe-32 align-self-center text-white"></i>
                </a>
            </div>
            <a href="<?php echo e(route('schdule-dates.index')); ?>" class="text-decoration-none">
                <p>Schedule Dates</p>
            </a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\dentist-crm\resources\views/schdule-settings.blade.php ENDPATH**/ ?>