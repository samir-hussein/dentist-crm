<?php $__env->startSection('content'); ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger" role="alert">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('success')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <div class="row my-4">
        <!-- Small table -->
        <div class="col-md-12">
            <div class="card shadow">
                <div class="card-body">
                    <!-- table -->
                    <table class="table datatables" id="dataTable-1">
                        <thead>
                            <tr>
                                <th>Patient Id</th>
                                <th>Patient Name</th>
                                <th>Patient Phone</th>
                                <th>Patient Phone 2</th>
                                <th>Branch</th>
                                <th>Doctor Name</th>
                                <th>Services</th>
                                <th>Appointment</th>
                                <th>Notes</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($appointment->patient->code); ?></td>
                                    <td><?php echo e($appointment->patient->name); ?></td>
                                    <td><?php echo e($appointment->patient->phone); ?></td>
                                    <td><?php echo e($appointment->patient->phone2); ?></td>
                                    <td><?php echo e($appointment->branch?->name); ?></td>
                                    <td><?php echo e($appointment->doctor->name); ?></td>
                                    <td><?php echo e($appointment->selectedServices); ?></td>
                                    <td><?php echo e($appointment->formatedTime); ?></td>
                                    <td><?php echo e($appointment->notes); ?></td>
                                    <td>
                                        <a class="btn mb-1 btn-sm btn-info"
                                            href="<?php echo e(route('appointments.edit', ['appointment' => $appointment->id])); ?>">Edit</a>

                                        <?php if(auth()->user()->is_admin || auth()->user()->is_doctor): ?>
                                            <a href="<?php echo e(route('appointments.markCompleted', ['appointment' => $appointment->id])); ?>"
                                                class="btn mb-1 btn-sm btn-success">Completed</a>
                                        <?php endif; ?>

                                        <a href="<?php echo e(route('patients.file', ['patient' => $appointment->patient->id])); ?>"
                                            class="btn mb-1 btn-sm btn-warning">Patient File</a>

                                        <form class="d-inline mb-1" method="POST"
                                            action="<?php echo e(route('appointments.destroy', ['appointment' => $appointment->id])); ?>">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div> <!-- simple table -->
    </div> <!-- end section -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $('#dataTable-1').DataTable({
            order: []
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\dentist-crm\resources\views/home.blade.php ENDPATH**/ ?>