<?php $__env->startSection('settings-active', 'active-link'); ?>

<?php $__env->startSection('buttons'); ?>
    <a href="<?php echo e(route('settings')); ?>"><button type="button" class="btn btn-dark"><span
                class="fe fe-arrow-left fe-12 mr-2"></span>Back</button></a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <style>
        a,
        a:hover {
            color: inherit;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row align-items-center">
        <div class="col-4 text-center">
            <div>
                <a href="<?php echo e(route('doses.index')); ?>" class="squircle bg-danger justify-content-center text-decoration-none">
                    <i class="fe fe-file-text fe-32 align-self-center text-white"></i>
                </a>
            </div>
            <a href="<?php echo e(route('doses.index')); ?>" class="text-decoration-none">
                <p>Doses</p>
            </a>
        </div>
        <div class="col-4 text-center">
            <div>
                <a href="<?php echo e(route('medicine-types.index')); ?>"
                    class="squircle bg-warning justify-content-center text-decoration-none">
                    <i class="fe fe-list fe-32 align-self-center text-white"></i>
                </a>
            </div>
            <a href="<?php echo e(route('medicine-types.index')); ?>" class="text-decoration-none">
                <p>Medicine Types</p>
            </a>
        </div>
        <div class="col-4 text-center">
            <div>
                <a href="<?php echo e(route('medicines.index')); ?>"
                    class="squircle bg-success justify-content-center text-decoration-none">
                    <i class="fe fe-thermometer fe-32 align-self-center text-white"></i>
                </a>
            </div>
            <a href="<?php echo e(route('medicines.index')); ?>" class="text-decoration-none">
                <p>Medicines</p>
            </a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\dentist-crm\resources\views/medicine-settings.blade.php ENDPATH**/ ?>