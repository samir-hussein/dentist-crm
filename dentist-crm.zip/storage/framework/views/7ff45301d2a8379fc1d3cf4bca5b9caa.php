<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td style="padding-bottom: 15px;font-size: 12px;font-family: cursive"><?php echo e($loop->iteration); ?></td>
        <td style="padding-bottom: 15px;font-size: 12px;font-family: cursive"><?php echo e($row->created_at->format('d-m-Y')); ?>

        </td>
        <td style="padding-bottom: 15px;font-size: 12px;font-family: cursive"><?php echo e($row->treatment); ?></td>
        <td style="padding-bottom: 15px;font-size: 12px;font-family: cursive"><?php echo e($row->fees); ?></td>
        <td style="padding-bottom: 15px;font-size: 12px;font-family: cursive"><?php echo e($row->paid); ?></td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<tr style="border-top:1px dashed black;padding: 1% 0 1% 0;border-bottom:1px solid black">
    <td colspan="3" style="font-weight: bold">Total :</td>
    <td style="font-weight: bold">L.E <?php echo e($data->sum('fees')); ?></td>
    <td style="font-weight: bold">L.E <?php echo e($data->sum('paid')); ?></td>
</tr>
<?php /**PATH D:\dentist-crm\resources\views/ajax-components/invoices.blade.php ENDPATH**/ ?>