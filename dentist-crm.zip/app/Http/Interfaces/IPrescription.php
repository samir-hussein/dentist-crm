<?php

namespace App\Http\Interfaces;

use Illuminate\Http\Request;

interface IPrescription
{
    public function index();
}
