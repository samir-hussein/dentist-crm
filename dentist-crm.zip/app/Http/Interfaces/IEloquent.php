<?php

namespace App\Http\Interfaces;

interface IEloquent {}
